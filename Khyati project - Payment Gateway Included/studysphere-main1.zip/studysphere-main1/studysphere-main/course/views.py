from pydoc import stripid
from urllib import request

from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm , PasswordChangeForm
from django.contrib.auth.models import User
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.views import PasswordChangeView
from django.contrib import messages
from django.urls import reverse, reverse_lazy
from paypal.standard.forms import PayPalPaymentsForm

from elearning.settings import PAYPAL_RECEIVER_EMAIL
from .forms import UserProfileForm, CourseForm
from .models import UserProfile, Course, CourseFile


def homepage(request):
    # Add any necessary data or logic here
    return render(request, 'homepage.html')


def register_user(request):
    if request.method == 'POST':
        user_form = UserCreationForm(request.POST)
        profile_form = UserProfileForm(request.POST)
        if user_form.is_valid() and profile_form.is_valid():
            user = user_form.save()
            profile = profile_form.save(commit=False)
            profile.user = user
            profile.save()
            messages.success(request, 'You have successfully registered.')
            return redirect('login')
    else:
        user_form = UserCreationForm()
        profile_form = UserProfileForm()
    return render(request, 'register.html', {'user_form': user_form, 'profile_form': profile_form})


def login_user(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            user_profile = user.userprofile
            if user_profile.user_type == 'instructor':
                return redirect('teacher_dashboard')
            elif user_profile.user_type == 'student':
                return redirect('student_dashboard')
            else:
                return redirect('dashboard')
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'login.html')

class PasswordChange(PasswordChangeView):
    form_class = PasswordChangeForm
    success_url = reverse_lazy('login')



def logout_user(request):
    logout(request)
    return redirect('login')


@login_required
def teacher_dashboard(request):
    courses = Course.objects.filter(user=request.user)

    if request.method == 'POST':
        form = CourseForm(request.POST, request.FILES)
        if form.is_valid():
            course = form.save(commit=False)
            course.user = request.user
            course.save()

            for file in request.FILES.getlist('files'):
                CourseFile.objects.create(course=course, file=file)

            return redirect('teacher_dashboard')

    else:
        form = CourseForm()

    context = {
        'courses': courses,
        'teacher': request.user,
        'form': form
    }
    return render(request, 'teacher_dashboard.html', context=context)


@login_required
def student_dashboard(request):
    user_profile = UserProfile.objects.get(user=request.user)
    paypal = request.GET.get("paypal", "")
    if paypal == "true":
        user_profile.plan = 'premium'
        user_profile.save()

    if user_profile.user_type == 'student':
        student_plan = user_profile.plan
        if not student_plan:
            student_plan = 'free'
        if student_plan == 'free':
            courses = Course.objects.filter(course_type=student_plan)
        else:
            courses = Course.objects.all()

        context = {
            'courses': courses,
            'student_plan': student_plan
        }

        return render(request, 'student_dashboard.html', context)
    else:
        return redirect('dashboard')


@login_required
def upgrade_plan(request):
    user_profile = UserProfile.objects.get(user=request.user)
    # if user_profile.user_type == 'student':


    paypal_dict = {
        "business": PAYPAL_RECEIVER_EMAIL,
        "amount": "10000000.00",
        "item_name": "name of the item",
        "invoice": "12345-67890",
        "notify_url": request.build_absolute_uri(reverse('paypal-ipn')),
        "return": request.build_absolute_uri(reverse('student_dashboard')),
        "cancel_return": request.build_absolute_uri(reverse('student_dashboard')),
        "custom": "upgrade all users",  # Custom command.
    }

    form = PayPalPaymentsForm(initial=paypal_dict)
    context = {"form": form}
    return render(request, "payment.html", context)

@login_required
def payment_page(request):
    return redirect('payment_page')


@login_required
def payment_confirm(request):
    # course = get_object_or_404(Course, id=course_id)
    if request.method == 'POST':
        student = get_object_or_404(UserProfile, user=request.user)
        student.plan = 'premium'
        student.save()
        return redirect('student_dashboard')

    return render(request, 'payment_page.html')


@login_required
def view_course_contents(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    return render(request, 'view_course_contents.html', {'course': course})


@login_required
def view_course_students(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    students = User.objects.filter(course=course)
    return render(request, 'view_course_students.html', {'course': course, 'students': students})


@login_required
def create_course(request):
    return render(request, 'create_course.html')


@login_required
def create_course_submit(request):
    if request.method == 'POST':
        form = CourseForm(request.POST, request.FILES)
        if form.is_valid():
            course = form.save(commit=False)
            course.user = request.user
            course.save()

            for file in request.FILES.getlist('files'):
                CourseFile.objects.create(course=course, file=file)

            return redirect('teacher_dashboard')


@login_required
def student_management_system(request):
    students = UserProfile.objects.filter(user_type='student')
    return render(request, 'student_management_system.html', {'students': students})


@login_required
def update_course(request, course_id):
    course = Course.objects.get(id=course_id)
    course_file = CourseFile.objects.filter(course=course)
    if request.method == 'POST':
        form = CourseForm(request.POST, request.FILES, instance=course)
        if form.is_valid():
            form.save()
            course_file.delete()
            for file in request.FILES.getlist('files'):
                CourseFile.objects.create(course=course, file=file)
            return redirect('teacher_dashboard')
    else:
        form = CourseForm(instance=course)

    return render(request, 'update_course.html', {'form': form, 'course': course})


def CreateCheckoutSession(APIView):
    def post(self, request):
        dataDict = dict(request.data)
        price = dataDict['price'][0]
        product_name = dataDict['product_name'][0]
        try:
            checkout_session = stripid.checkout.Session.create(
                line_items=[{
                    'price_data': {
                        'currency': 'usd',
                        'product_data': {
                            'name': product_name,
                        },
                        'unit_amount': price
                    },
                    'quantity': 1
                }],
                mode='payment',
            )
            return redirect('student_dashboard', code=303)
        except Exception as e:
            print(e)
            return e


def successful_payment(request):
    return render(request, student_dashboard)

def cancelled_payment(request):
    return render(request, student_dashboard)